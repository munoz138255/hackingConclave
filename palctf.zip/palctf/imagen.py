from pyzbar import pyzbar
from PIL import Image

image = Image.open('/home/kali/Escritorio/imagen_qr.png')
qr_code = pyzbar.decode(image)[0]

data = qr_code.data.decode('utf8')
print("Contenido: ",data)
