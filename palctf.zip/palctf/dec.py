import base64

# Cadena Base64 que representa una imagen PNG
cadena_base64 = "iVBORw0KGgoAAAANSUhEUgAAAG8AAABvAQMAAADYCwwjAAAABlBMVEUAAAD///+l2Z/dAAAAAnRSTlP//8i138cAAAAJcEhZcwAACxIAAAsSAdLdfvwAAAElSURBVDiN1dS9jcUgDAdwRyno7hZA8hp0rAQL5GMBshId=="

# Decodificar la cadena Base64
datos_imagen = base64.b64decode(cadena_base64)

# Guardar los datos decodificados como un archivo de imagen
with open("imagen.png", "wb") as archivo:
    archivo.write(datos_imagen)
