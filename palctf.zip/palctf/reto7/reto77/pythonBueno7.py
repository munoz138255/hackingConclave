import requests
import sys

cookie_file = "gato.txt"
url = "http://conclave.tlm.unavarra.es:42104/"

# Leer las cookies del archivo
cookies = {}
with open(cookie_file, 'r') as f:
    for line in f:
        parts = line.strip().split('=')
        if len(parts) == 2:
            cookies[parts[0]] = parts[1]

for i in range(1, 101):
    # Realizar la solicitud HTTP con las cookies y desactivar la caché
    response = requests.get(url, cookies=cookies, headers={'Cache-Control': 'no-cache'})

    if response.status_code == 200:
        # Guardar la imagen descargada
        with open(f"image_{i:03d}.jpg", 'wb') as f:
            f.write(response.content)
    else:
        print("No se pudo obtener la imagen. Código de estado:", response.status_code)
        sys.exit(1)
