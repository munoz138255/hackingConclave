#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <curl/curl.h>

// Esta función será llamada por libcurl cuando reciba datos
size_t write_data(void *ptr, size_t size, size_t nmemb, FILE *stream) {
    return fwrite(ptr, size, nmemb, stream);
}

int main(void) {
    CURL *curl;
    FILE *fp;
    CURLcode res;
    char url[100]; // Espacio para almacenar la URL
    time_t t;

    // Inicializar libcurl
    curl = curl_easy_init();
    if (curl) {
        // Inicializar el generador de números aleatorios
        srand((unsigned) time(&t));

        // Realizar 100 solicitudes
        for (int i = 0; i < 300; i++) {
            // Abrir un nuevo archivo para cada imagen
            char filename[20];
            sprintf(filename, "image_%03d.jpg", i + 1);
            fp = fopen(filename, "wb");

            // Construir la URL con parámetros únicos (sello de tiempo + número aleatorio)
            sprintf(url, "http://conclave.tlm.unavarra.es:42104/?timestamp=%ld&rand=%d", (long) time(NULL), rand());

            // Configurar la URL de la solicitud
            curl_easy_setopt(curl, CURLOPT_URL, url);

            // Configurar la función de callback para escribir datos en el archivo
            curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_data);

            // Pasar el puntero al archivo como el usuario de la función de callback
            curl_easy_setopt(curl, CURLOPT_WRITEDATA, fp);

            // Activar la gestión de cookies
            curl_easy_setopt(curl, CURLOPT_COOKIEFILE, "kaixo.txt");
            curl_easy_setopt(curl, CURLOPT_COOKIEJAR, "kaixo.txt");

            // Realizar la solicitud
            res = curl_easy_perform(curl);
            if (res != CURLE_OK) {
                fprintf(stderr, "Error en la solicitud: %s\n", curl_easy_strerror(res));
            }

            // Cerrar el archivo
            fclose(fp);
        }

        // Finalizar libcurl
        curl_easy_cleanup(curl);
    }

    return 0;
}
