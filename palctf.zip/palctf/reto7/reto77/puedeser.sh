touch gato.txt
cookie_file="gato.txt"
url="http://conclave.tlm.unavarra.es:42104/"

for i in $(seq 1 100); do
    # Descargar la imagen usando wget con las cookies
    wget --no-cache --load-cookies "$cookie_file" -O imagen_qr${i}.png --save-cookies "$cookie_file" "$url"
done
rm gato.txt
