cookie_file="taf.txt"
url="http://conclave.tlm.unavarra.es:42104/"
total_solicitudes=150

# Utiliza xargs para ejecutar múltiples instancias de curl en paralelo
seq 1 $total_solicitudes | xargs -P 1 -I {} sh -c 'curl -o "imagen_qr$1.png" --cookie-jar "$2" --cookie "$2" "$3"' _ {} "$cookie_file" "$url"
