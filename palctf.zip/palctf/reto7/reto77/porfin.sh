touch asisi.txt
frase=""
frase_tot=""
for i in $(seq 1 76); do
    frase=$(python copia7.py "imagen_qr${i}.png")
    frase_tot="${frase_tot}${frase}"
done
echo "$frase_tot" > asisi.txt
