#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int main(void) {
    FILE *fp;
    char command[100]; // Espacio para almacenar el comando
    char response[100]; // Espacio para almacenar la respuesta del comando
    time_t t;

    // Inicializar el generador de números aleatorios
    srand((unsigned) time(&t));

    // Abrir el archivo para escribir
    fp = fopen("resultados.txt", "w");
    if (fp == NULL) {
        printf("Error al abrir el archivo.");
        return 1;
    }

    // Realizar 100 solicitudes
    for (int i = 1; i <= 260; i++) {
        // Construir el nombre de archivo
        char filename[20];
        sprintf(filename, "image_%03d.jpg", i);

        // Construir el comando para ejecutar el script de Python con el nombre de archivo como argumento
        sprintf(command, "python copia7.py %s", filename);

        // Abrir un tubo para leer la salida del comando
        FILE *pipe = popen(command, "r");
        if (pipe == NULL) {
            printf("Error al abrir el tubo para el comando.");
            return 1;
        }

        // Leer la salida del comando
        fgets(response, sizeof(response), pipe);

        // Cerrar el tubo
        pclose(pipe);

        // Eliminar el salto de línea de la respuesta (si existe)
        char *newline = strchr(response, '\n');
        if (newline != NULL) {
            *newline = '\0';
        }

        // Escribir la respuesta en el archivo sin espacios
        fputs(response, fp);
    }

    // Cerrar el archivo
    fclose(fp);

    return 0;
}
