import base64

cadena_codificada = "iVBORw0KGgoAAAANSUhEUgAAAG8AAABvAQMAAADYCwwjAAAABlBMVEUAAAD///+l2Z/dAAAAAnRSTlP//8i138cAAAAJcEhZcwAACxIAAAsSAdLdfvwAAAElSURBVDiN1dS9jcUgDAdwRyno7hZA8hp0rAQL5GMBshIda0RiAdJRoPj8ondfxcU0rziUIr8Cgf+xA/Rrwf9gAZgsToo slow!!"
longitud_relleno = len(cadena_codificada) % 4
cadena_codificada += '=' * (4 - longitud_relleno)  # Agrega el relleno adecuado

cadena_decodificada = base64.b64decode(cadena_codificada).decode('latin-1')

print(cadena_decodificada)
