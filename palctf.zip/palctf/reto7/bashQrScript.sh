curl --output imagen_qr.png "http://conclave.tlm.unavarra.es:42103/index.php?showmeqr=showme"
python qrscript.py
