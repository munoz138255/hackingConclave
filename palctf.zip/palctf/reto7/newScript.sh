import sys
from pyzbar import pyzbar
from PIL import Image

def leer_qr(ruta_imagen):
    image = Image.open(ruta_imagen)
    qr_code = pyzbar.decode(image)[0]
    data = qr_code.data.decode('utf8').encode('shift-jis').decode('utf-8')
    return data

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Uso: python script7.py <ruta_imagen>")
        sys.exit(1)

    ruta_imagen = sys.argv[1]
    resultado = leer_qr(ruta_imagen)
    print(resultado)
