import requests
from pyzbar import pyzbar
from PIL import Image
import webbrowser

image = Image.open('/home/kali/Escritorio/imagen_qr.png')
qr_code = pyzbar.decode(image)[0]

data = qr_code.data.decode('utf8')
print("Contenido: ",data)
# URL del formulario de inicio de sesión
url_b= 'http://conclave.tlm.unavarra.es:42103/index.php?'
passw = data
# Datos del formulario (en este caso, la contraseña)
url = url_b + 'password=' + passw

webbrowser.open(url)
# Realizar la solicitud POST con los datos del formulario
