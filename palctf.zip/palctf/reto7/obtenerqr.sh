#!/bin/bash

cookie_file="popin.txt"
url="http://conclave.tlm.unavarra.es:42104/"
ultima="Too slow!!"
frase=""
frase_ant="."
touch qr.txt
i=1
while [ "$frase" != "$ultima" ]; do
    curl --output imagen_qr${i}.png --cookie-jar "$cookie_file" --cookie "$cookie_file" "$url"
    frase_ant="$frase"
    frase=$(python script7.py "imagen_qr${i}.png")
    ((i++))
done
