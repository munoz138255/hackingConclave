import requests
from pyzbar import pyzbar
from PIL import Image
import webbrowser

image_path = '/home/kali/Escritorio/conclave/reto7/imagen_qr.png'

# Descargar la imagen
url = 'http://conclave.tlm.unavarra.es:42104/'
response = requests.get(url)
with open(image_path, 'wb') as f:
    f.write(response.content)

# Convertir la imagen a RGBA para manejar la transparencia
image = Image.open(image_path).convert('RGBA')

qr_code = pyzbar.decode(image)[0]

data = qr_code.data.decode('utf8').encode('shift-jis').decode('utf-8')
print(data)
