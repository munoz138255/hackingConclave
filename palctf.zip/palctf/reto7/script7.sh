#!/bin/bash

cookie_file="2.txt"
url="http://conclave.tlm.unavarra.es:42104/"
ultima="Too slow!!"
frase=""
frase_ant="."
touch qr.txt

while [ "$frase" != "$ultima" ]; do
    curl --output imagen_qr.png --cookie-jar "$cookie_file" --cookie "$cookie_file" "$url"
    frase_ant="$frase"
    frase=$(python ayuda.py)
    echo -n "$frase " >> qr.txt
done
