from selenium import webdriver
import zxing
import requests

# Inicializa el navegador (en este caso, Chrome)
driver = webdriver.Firefox()

try:
    # Abre la página web con el código QR
    driver.get("http://conclave.tlm.unavarra.es:42103/index.php?showmeqr=C0ncl4ve")

    # Encuentra el elemento <img> que contiene el código QR
    img_elemento = driver.find_element_by_tag_name('img')

    # Obtiene el valor del atributo src, que contiene la URL del código QR
    src_url = img_elemento.get_attribute('src')
    print("URL del código QR:", src_url)

    # Decodificar el código QR desde la imagen
    lector_codigo = zxing.BarCodeReader()
    try:
        resultado = lector_codigo.decode(src_url)
        contenido_qr = resultado["raw"]
        print("Contenido del código QR:", contenido_qr)

        # Modificar la URL para incluir el contenido del código QR como parámetro
        url = f"http://conclave.tlm.unavarra.es:42103/?password={contenido_qr}"

        # Realizar la solicitud GET
        respuesta = requests.get(url)

        # Verificar si la solicitud fue exitosa (código de estado 200)
        if respuesta.status_code == 200:
            print('Solicitud GET exitosa')
            print('Respuesta del servidor:')
            print(respuesta.text)  # Imprimir la respuesta del servidor
        else:
            print('Error al enviar la solicitud GET')
            print('Código de estado:', respuesta.status_code)

    except zxing.BarCodeReaderException as e:
        print("Error al decodificar el código QR:", e)

finally:
    # Cierra el navegador
    driver.quit()
