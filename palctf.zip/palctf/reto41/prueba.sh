#!/bin/bash

pi="141592653589793238462643383279502884197169"

# Convertir la cadena de dígitos en un array
pi_array=($(echo $pi | grep -o .))

# Recorrer el array e imprimir cada dígito
for digito in "${pi_array[@]}"; do
    echo "$digito"
done
