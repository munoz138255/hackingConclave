#!/bin/bash

pi="141592653589793238462643383279502884197169"
piC="3."
res=""
texto=""
touch sol.txt
pi_array=($(echo $pi | grep -o .))
for num in "${pi_array[@]}"; do
    piC+="$num"
    res=$(curl -s "http://baymax.tlm.unavarra.es:42141/${piC}" | grep -m 1 '<span>' | sed 's/<[^>]*>//g')
    texto+="$res"
done
echo $texto > sol.txt
